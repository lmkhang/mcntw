<section id="counter-section">
    <div id="counter-up-trigger" class="counter-up text-white parallax" data-stellar-background-ratio="0.5"
         style="background-image: url({{URL::asset('assets/img/counter-bg.jpg')}});">
        <div class="cover"></div>
        <!-- Begin page header-->
        <div class="page-header-wrapper">
            <div class="container">
                <div class="page-header text-center wow fadeInDown" data-wow-delay="0.4s">
                    <h2>Some Fun Facts</h2>

                    <div class="devider"></div>
                    <p class="subtitle">Before anyone is not told</p>
                </div>
            </div>
        </div>
        <!-- End page header-->
        <div class="container">

            <div class="row">

                <div class="fact text-center col-md-3 col-sm-6">
                    <div class="fact-inner">
                        <i class="fa fa-users fa-3x"></i>

                        <div class="extra-space-l"></div>
                        <span class="counter">6666</span>

                        <p class="lead">Clients Worked With</p>
                    </div>
                </div>

                <div class="fact text-center col-md-3 col-sm-6">
                    <div class="fact-inner">
                        <i class="fa fa-leaf fa-3x"></i>

                        <div class="extra-space-l"></div>
                        <span class="counter">800</span>

                        <p class="lead">Completed Projects</p>
                    </div>
                </div>

                <div class="fact text-center col-md-3 col-sm-6">
                    <div class="fact-inner">
                        <i class="fa fa-trophy fa-3x"></i>

                        <div class="extra-space-l"></div>
                        <span class="counter">55</span>

                        <p class="lead">Winning Awards</p>
                    </div>
                </div>

                <div class="fact last text-center col-md-3 col-sm-6">
                    <div class="fact-inner">
                        <i class="fa fa-coffee fa-3x"></i>

                        <div class="extra-space-l"></div>
                        <span class="counter">1100</span>

                        <p class="lead">Cups of coffee drinking</p>
                    </div>
                </div>

            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </div>
</section>