<section id="team-section" class="page">
    <!-- Begin page header-->
    <div class="page-header-wrapper">
        <div class="container">
            <div class="page-header text-center wow fadeInDown" data-wow-delay="0.4s">
                <h2>Our Team</h2>

                <div class="devider"></div>
                <p class="subtitle">Meat our experts</p>
            </div>
        </div>
    </div>
    <!-- End page header-->
    <div class="container">
        <div class="row">
            <div class="team-items">
                <div class="col-md-2">
                    <div class="team-container wow bounceIn" data-wow-delay="0.2s">
                        <div class="team-item">
                            <div class="team-triangle">
                                <div class="content">
                                    <img src="{{URL::asset('assets/img/team/1.jpg')}}" alt="title"/>

                                    <div class="team-hover text-center">
                                        <i class="fa fa-male"></i>

                                        <p>John Doe</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="team-container wow bounceIn" data-wow-delay="0.3s">
                        <div class="team-item">
                            <div class="team-triangle">
                                <div class="content">
                                    <img src="{{URL::asset('assets/img/team/1.jpg')}}" alt="title"/>

                                    <div class="team-hover text-center">
                                        <i class="fa fa-female"></i>

                                        <p>Jane Doe</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="team-container wow bounceIn" data-wow-delay="0.4s">
                        <div class="team-item">
                            <div class="team-triangle">
                                <div class="content">
                                    <img src="{{URL::asset('assets/img/team/1.jpg')}}" alt="title"/>

                                    <div class="team-hover text-center">
                                        <i class="fa fa-male"></i>

                                        <p>John Doe</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-2">
                    <div class="team-container wow bounceIn" data-wow-delay="0.5s">
                        <div class="team-item">
                            <div class="team-triangle">
                                <div class="content">
                                    <img src="{{URL::asset('assets/img/team/1.jpg')}}" alt="title"/>

                                    <div class="team-hover text-center">
                                        <i class="fa fa-male"></i>

                                        <p>John Doe</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="team-container wow bounceIn" data-wow-delay="0.6s">
                        <div class="team-item">
                            <div class="team-triangle">
                                <div class="content">
                                    <img src="{{URL::asset('assets/img/team/1.jpg')}}" alt="title"/>

                                    <div class="team-hover text-center">
                                        <i class="fa fa-male"></i>

                                        <p>John Doe</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="team-container wow bounceIn" data-wow-delay="0.7s">
                        <div class="team-item">
                            <div class="team-triangle">
                                <div class="content">
                                    <img src="{{URL::asset('assets/img/team/1.jpg')}}" alt="title"/>

                                    <div class="team-hover text-center">
                                        <i class="fa fa-male"></i>

                                        <p>John Doe</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="team-container wow bounceIn" data-wow-delay="0.8s">
                        <div class="team-item">
                            <div class="team-triangle">
                                <div class="content">
                                    <img src="{{URL::asset('assets/img/team/1.jpg')}}" alt="title"/>

                                    <div class="team-hover text-center">
                                        <i class="fa fa-female"></i>

                                        <p>Jane Doe</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>

</section>