@extends('templates.master', ['joinus'=> $joinus ])

@section('title', 'Home')
