<?php $__env->startSection('title', 'Home'); ?>

<?php echo $__env->make('templates.master', ['joinus'=> $joinus ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>