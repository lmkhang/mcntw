<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //get Info of API
        $api_key = \App\Config::where(['prefix' => 'daily', 'name' => 'api_key', 'del_flg' => 1])->get()[0]['value'];
        $url_oauth = \App\Config::where(['prefix' => 'daily', 'name' => 'url_oauth', 'del_flg' => 1])->get()[0]['value'];
        $api_secret = \App\Config::where(['prefix' => 'daily', 'name' => 'api_secret', 'del_flg' => 1])->get()[0]['value'];
        $url_callback = \App\Config::where(['prefix' => 'daily', 'name' => 'url_callback', 'del_flg' => 1])->get()[0]['value'];

        $urlHome = config('app.url');

        $urlOAuthor = str_replace(array('{API_KEY}', '{URL_CALLBACK}'), array($api_key, $urlHome.$url_callback), $url_oauth);
        return view('welcome')->with('OAuthor', $urlOAuthor);
    }


    public function create()
    {
        return view("create");
    }

    public function callback(Request $request)
    {
        $get = $request->all();

        echo '<pre/>';
        print_r($get);
        exit;
    }
}