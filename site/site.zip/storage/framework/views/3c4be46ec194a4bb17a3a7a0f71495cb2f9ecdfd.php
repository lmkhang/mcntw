<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form trong Laravel 5</title>
</head>
<body>
<h1>Them Bai Viet Moi</h1>
<?php echo Form::open(['url'=>'articles', 'method'=>'post']); ?>

    <?php echo Form::label('name','Name:'); ?>

    <?php echo Form::text('name'); ?>


    <?php echo Form::submit('Them moi'); ?>

<?php echo Form::close(); ?>

</body>
</html>